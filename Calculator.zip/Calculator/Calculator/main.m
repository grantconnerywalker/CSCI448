//
//  main.m
//  Calculator
//
//  Created by Andrew Grossnickle on 1/18/15.
//  Copyright (c) 2015 agrossnickle_gwalker. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
